﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SqlServerTestApp
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            this.OpenNewForm<Form32>();
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

            int? Agent_code = null;
            DateTime Date;
            int? Summ = null;
            DateTime Term;
            int? Payment = null;
            int? Contact = null;

            try
            {
                Date = Convert.ToDateTime(dateTimePicker1.Text);
                Summ = Convert.ToInt32(textBox1.Text);
                Term = Convert.ToDateTime(dateTimePicker2.Text);
                Payment = Convert.ToInt32(textBox3.Text);
                Contact = Convert.ToInt32(textBox4.Text);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string query = @"INSERT INTO Contract(Agent_code, Date, Summ, Term, Payment, Contact) 
values(" + $" '{Agent_code}','{Date}','{Summ}','{Term}', '{Payment}', '{Contact}' " + ")"
;

            int? result = DBConnectionService.SendCommandToSqlServer(query);
            if (result != null && result > 0)
            {
                MessageBox.Show("Добавлено!", "Сохранение", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            string s = textBox3.Text;
            if (s.Count() == 1000000)
            {
                textBox3.MaxLength = 1000000;
            }
        }

        private void textBox4_TextChanged_1(object sender, EventArgs e)
        {
            string s = textBox4.Text;
            if (s.Count() == 10)
            {
                textBox4.MaxLength = 10;
            }
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            string s = textBox1.Text;
            if (s.Count() == 1000000)
            {
                textBox1.MaxLength = 1000000;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar <= 47 || e.KeyChar >= 58) && e.KeyChar != 8)
                e.Handled = true;
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar <= 47 || e.KeyChar >= 58) && e.KeyChar != 8)
                e.Handled = true;
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar <= 47 || e.KeyChar >= 58) && e.KeyChar != 8)
                e.Handled = true;
        }
    }
}