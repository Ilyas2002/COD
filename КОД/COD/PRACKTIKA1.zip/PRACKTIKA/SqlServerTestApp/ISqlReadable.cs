﻿namespace SqlServerTestApp
{
    public interface ISqlReadable
    {
        void ParseData();
    }
}