﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SqlServerTestApp
{
    public partial class Form17 : Form
    {
        public Form17()
        {
            InitializeComponent();
        }

        private void Form17_Load(object sender, EventArgs e)
        {

            string query = @"select [Code_in], [Title], [App]

                From [dbo].[Insurance_type] where [Title] = 'Получил автомобильную страховку'";
            ;
            FormExtentions.ClearAndAddColumnsInDataGridView(dataGridView1, "Code_in", "Title", "App");
            var list = DBConnectionService.SendQueryToSqlServer(query);

            if (list == null || list.Any())
            {
                return;
            }

            dataGridView1.Columns.Add("[Code_in]", "Code_in");

            dataGridView1.Columns.Add("[Title]", "Title");

            dataGridView1.Columns.Add("[App]", "App");

            foreach (var row in list)
            {
                dataGridView1.Rows.Add(row[0], row[1], row[2]);
            }
            dataGridView1.Refresh();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}