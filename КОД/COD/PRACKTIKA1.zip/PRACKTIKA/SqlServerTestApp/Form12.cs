﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SqlServerTestApp
{
    public partial class Form12 : Form
    {
        public Form12()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            this.OpenNewForm<Form8>();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Int32? Branch_cd = null;
            string Fio = null;
            string Pol = null;
            Int64? Number_ct = null;

            try
            {
                Branch_cd = Convert.ToInt32(textBox2.Text);
                Fio = Convert.ToString(textBox3.Text);
                Pol = Convert.ToString(textBox4.Text);
                Number_ct = Convert.ToInt64(textBox5.Text);
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string query = @"INSERT INTO Insurance_agent(Branch_cd, Fio, Pol, Number_ct)
values(" + $" '{Branch_cd}','{Fio}','{Pol}','{Number_ct}'" + ")"
;
            int? result = DBConnectionService.SendCommandToSqlServer(query);
            if (result != null && result > 0)
            {
                MessageBox.Show("Добавлено!", "Сохранение", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar <= 47 || e.KeyChar >= 58) && e.KeyChar != 8)
                e.Handled = true;
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar <= 47 || e.KeyChar >= 58) && e.KeyChar != 8)
                e.Handled = true;
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            {
                char l = e.KeyChar;
                if ((l < 'А' || l > 'я') && l != '\b' && l != '.')
                    if((l < 'A' || l > 'z') && l != '\b' && l != '.')
                {
                    e.Handled = true;
                }
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            {
                char l = e.KeyChar;
                if ((l < 'А' || l > 'я') && l != '\b' && l != '.')
                    if((l < 'A' || l > 'z') && l != '\b' && l != '.')
                {
                    e.Handled = true;
                }
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string s = textBox5.Text;
            if (s.Count() == 10)
            {
                textBox2.MaxLength = 10;
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            string s = textBox5.Text;
            if (s.Count() == 11)
            {
                textBox5.MaxLength = 11;
            }
        }

        private void Form12_Load(object sender, EventArgs e)
        {

        }
    }
}
