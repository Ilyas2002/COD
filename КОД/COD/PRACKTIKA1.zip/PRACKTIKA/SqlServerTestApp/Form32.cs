﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SqlServerTestApp
{
    public partial class Form32 : Form
    {
        public Form32()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            
            string FIO = null;
            string Adress_cl = null;
            Int64? Number_cl = null;

            try
            {
                FIO = Convert.ToString(textBox2.Text);
                Adress_cl = Convert.ToString(textBox3.Text);
                Number_cl = Convert.ToInt64(textBox4.Text);
            }
            catch(Exception exc)
            {
                MessageBox.Show(exc.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string query = @"INSERT INTO Customer_data(FIO, Adress_cl, Number_cl) 
values(" + $" '{FIO}','{Adress_cl}','{Number_cl}'" + ")"
;
            int? result = DBConnectionService.SendCommandToSqlServer(query);
            if (result != null && result > 0)
            {
                MessageBox.Show("Добавлено!", "Сохранение", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void Form32_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.OpenNewForm<Form12>();
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            {
                char l = e.KeyChar;
                if ((l < 'А' || l > 'я') && l != '\b' && l != '.')
                    if((l < 'A' || l > 'z') && l != '\b' && l != '.')
                {
                    e.Handled = true;
                }
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            {
                char l = e.KeyChar;
                if ((l < 'А' || l > 'я') && l != '\b' && l != '.')
                    if((l < 'A' || l > 'z') && l != '\b' && l != '.')
                {
                    e.Handled = true;
                }
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar <= 47 || e.KeyChar >= 58) && e.KeyChar != 8)
                e.Handled = true;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            string s = textBox4.Text;
            if (s.Count() == 11)
            {
                textBox4.MaxLength = 11;
            }
        }
    }
}